package com.example.quizapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class SetNameDialogActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.set_name_dialog)

        // You can add further logic here, such as button click listeners
    }
}
