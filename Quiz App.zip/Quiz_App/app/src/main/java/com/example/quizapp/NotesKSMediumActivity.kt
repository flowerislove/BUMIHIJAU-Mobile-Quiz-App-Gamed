package com.example.quizapp

import android.view.View
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.quizapp.NotesKSMediumActivity
import com.example.quizapp.databinding.ActivityNotesKsmediumBinding

class NotesKSMediumActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityNotesKsmediumBinding.inflate(layoutInflater)
    }

    private val questionsAndOptions = listOf(
        Triple(
            "1. Apakah proses pertama dalam kitar semula kaca?",
            listOf(
                "A) Meleburkan kaca",
                "B) Mengasingkan kaca mengikut warna",
                "C) Membakar kaca",
                "D) Menyusun kaca di kilang"
            ),
            "B"
        ),
        Triple(
            "2. Apakah bahan mentah yang dapat dijimatkan melalui kitar semula kertas?",
            listOf(
                "A) Minyak",
                "B) Pasir",
                "C) Kayu",
                "D) Plastik"
            ),
            "C"
        ),
        Triple(
            "3. Mengapa aluminium penting untuk dikitar semula?",
            listOf(
                "A) Untuk mengurangkan pencemaran air",
                "B) Untuk menjimatkan tenaga berbanding menghasilkan aluminium baharu",
                "C) Untuk mencipta produk yang lebih besar",
                "D) Untuk menghapuskan sisa elektronik"
            ),
            "B"
        ),
        Triple(
            "4. Apakah maksud ‘downcycling’?",
            listOf(
                "A) Proses mengitar semula bahan kepada produk berkualiti lebih rendah",
                "B) Proses menjadikan bahan kitar semula lebih berkualiti",
                "C) Menghapuskan bahan sisa secara kekal",
                "D) Menggabungkan semua bahan kitar semula"
            ),
            "A"
        ),
        Triple(
            "5. Apakah peranan utama pusat kitar semula?",
            listOf(
                "A) Membakar semua sisa buangan",
                "B) Mengumpulkan dan mengasingkan sisa kitar semula",
                "C) Mengurangkan tenaga manusia",
                "D) Menghasilkan lebih banyak sisa"
            ),
            "B"
        ),
        Triple(
            "6. Apakah kesan positif kitar semula terhadap alam sekitar?",
            listOf(
                "A) Menambah pencemaran udara",
                "B) Mengurangkan penggunaan bahan mentah baharu",
                "C) Meningkatkan penggunaan tenaga",
                "D) Menghapuskan tumbuhan hijau"
            ),
            "B"
        ),
        Triple(
            "7. Bagaimanakah sisa elektronik dikitar semula?",
            listOf(
                "A) Dengan membuangnya ke laut",
                "B) Dengan menanam di dalam tanah",
                "C) Dengan memisahkan komponen logam berharga",
                "D) Dengan mencairkan semua bahagian plastik"
            ),
            "C"
        ),
        Triple(
            "8. Bahan yang dikitar semula kepada produk baharu berkualiti tinggi dipanggil…",
            listOf(
                "A) Downcycling",
                "B) Upcycling",
                "C) Landfilling",
                "D) Incinerating"
            ),
            "B"
        ),
        Triple(
            "9. Apakah bahan yang sukar dikitar semula?",
            listOf(
                "A) Botol kaca jernih",
                "B) Polistirena (Styrofoam)",
                "C) Tin aluminium",
                "D) Kertas surat khabar"
            ),
            "B"
        ),
        Triple(
            "10. Apakah maksud ‘recovery’ dalam sistem pengurusan sisa?",
            listOf(
                "A) Menggunakan sisa sebagai tenaga atau bahan mentah baharu",
                "B) Membakar semua sisa yang tidak berguna",
                "C) Mengumpulkan sisa buangan di tapak pelupusan",
                "D) Membiarkan sisa terbiar"
            ),
            "A"
        )
    )

    private var currentQuestionIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        displayQuestion()

        binding.option1Button.setOnClickListener { checkAnswer("A") }
        binding.option2Button.setOnClickListener { checkAnswer("B") }
        binding.option3Button.setOnClickListener { checkAnswer("C") }
        binding.option4Button.setOnClickListener { checkAnswer("D") }

        binding.nextButton.setOnClickListener {
            loadNextQuestion()
        }
    }

    private fun displayQuestion() {
        if (currentQuestionIndex < questionsAndOptions.size) {
            val (question, options, _) = questionsAndOptions[currentQuestionIndex]
            binding.questionPlaceholder.text = question
            binding.option1Button.text = options[0]
            binding.option2Button.text = options[1]
            binding.option3Button.text = options[2]
            binding.option4Button.text = options[3]
            enableOptionButtons() // Ensure option buttons are enabled for the next question
        } else {
            binding.questionPlaceholder.text = "Ulangkaji tamat!"
            disableOptionButtons()
            binding.nextButton.isEnabled = false // Disable the Next button when the quiz ends
            showHomeButton()
        }
    }

    private fun checkAnswer(selectedAnswer: String) {
        val (_, _, correctAnswer) = questionsAndOptions[currentQuestionIndex]
        if (selectedAnswer == correctAnswer) {
            Toast.makeText(this, "Jawapan betul!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Jawapan salah! Jawapan betul: $correctAnswer", Toast.LENGTH_SHORT)
                .show()
        }
        disableOptionButtons() // Disable option buttons after answering
    }

    private fun loadNextQuestion() {
        if (currentQuestionIndex < questionsAndOptions.size - 1) {
            currentQuestionIndex++
            displayQuestion()
        } else {
            Toast.makeText(this, "Ulangkaji tamat!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun disableOptionButtons() {
        binding.option1Button.isEnabled = false
        binding.option2Button.isEnabled = false
        binding.option3Button.isEnabled = false
        binding.option4Button.isEnabled = false
    }

    private fun enableOptionButtons() {
        binding.option1Button.isEnabled = true
        binding.option2Button.isEnabled = true
        binding.option3Button.isEnabled = true
        binding.option4Button.isEnabled = true
    }

    private fun showHomeButton() {
        binding.homeButton.apply {
            text = "Halaman Utama"
            isEnabled = true
            visibility = View.VISIBLE
            setOnClickListener {
                // Navigate to home page
                val intent = Intent(this@NotesKSMediumActivity, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}