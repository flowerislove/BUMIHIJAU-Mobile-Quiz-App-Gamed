package com.example.quizapp

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.quizapp.databinding.ActivityQuestionBinding
import com.shashank.sony.fancytoastlib.FancyToast

class QuestionActivity : AppCompatActivity() {
    private lateinit var binding: ActivityQuestionBinding

    private var selectedAns: String = ""
    private var correctAns: String = ""
    private var questionNo = 0
    private var score = 0

    // Full list of questions
    private val questions = listOf(
        "1. Apakah maksud kitar semula?\nA) Menggunakan semula barangan lama\nB) Membakar sisa buangan\nC) Mengubah bahan terpakai menjadi produk baharu\nD) Membawa barang ke tapak pelupusan",
        "2. Apakah bahan berikut yang boleh dikitar semula?\nA) Plastik, kertas, kaca\nB) Plastik, sisa makanan, kayu\nC) Batu, pasir, tanah\nD) Kaca, seramik, logam berat",
        "3. Warna tong kitar semula untuk plastik ialah…\nA) Hijau\nB) Biru\nC) Kuning\nD) Merah",
        "4. Simbol kitar semula berbentuk…\nA) Segi tiga dengan tiga anak panah\nB) Lingkaran dengan satu anak panah\nC) Bulatan penuh\nD) Segi empat dengan satu anak panah",
        "5. Apakah bahan yang tidak boleh dikitar semula?\nA) Kertas\nB) Botol kaca\nC) Bekas makanan yang berminyak\nD) Tin aluminium",
        "6. Mengapa penting untuk mengitar semula?\nA) Untuk mengurangkan pencemaran dan menjimatkan sumber\nB) Untuk meningkatkan pencemaran\nC) Untuk menghasilkan lebih banyak sisa\nD) Untuk membuang semua barang lama",
        "7. E-waste merujuk kepada…\nA) Sisa elektronik seperti telefon bimbit dan komputer\nB) Sisa makanan yang dibuang\nC) Sisa daripada kilang\nD) Barang terbuang yang besar",
        "8. Kertas yang boleh dikitar semula ialah…\nA) Kertas bersalut minyak\nB) Kertas surat khabar lama\nC) Kertas yang sangat basah\nD) Kertas yang koyak dan kotor",
        "9. Apakah yang perlu dilakukan dengan sisa plastik sebelum dikitar semula?\nA) Campurkan dengan sisa makanan\nB) Bakar terlebih dahulu\nC) Bersihkan dan asingkan mengikut jenis\nD) Masukkan terus ke tong hijau",
        "10. Proses kitar semula boleh membantu…\nA) Mengurangkan penggunaan tenaga\nB) Menghasilkan lebih banyak sampah\nC) Mengurangkan penghasilan produk baharu\nD) Menghapuskan sumber alam sepenuhnya"
    )

    // Full list of correct answers
    private val correctAnswers = listOf(
        "C", "A", "C", "A", "C", "A", "A", "B", "C", "A"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuestionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showQuestion()

        binding.optionA.setOnClickListener { handleOptionSelected("A", binding.optionA) }
        binding.optionB.setOnClickListener { handleOptionSelected("B", binding.optionB) }
        binding.optionC.setOnClickListener { handleOptionSelected("C", binding.optionC) }
        binding.optionD.setOnClickListener { handleOptionSelected("D", binding.optionD) }

        binding.nextQuestionButton.setOnClickListener {
            if (selectedAns.isEmpty()) {
                FancyToast.makeText(
                    this,
                    "Sila pilih jawapan",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.INFO,
                    false
                ).show()
            } else {
                checkAnswer()
                loadNextQuestionOrFinish()
            }
        }
    }

    private fun showQuestion() {
        if (questionNo < questions.size) {
            val questionParts = questions[questionNo].split("\n")
            binding.question.text = questionParts[0] // Question text
            binding.optionA.text = questionParts.getOrNull(1) ?: "A"
            binding.optionB.text = questionParts.getOrNull(2) ?: "B"
            binding.optionC.text = questionParts.getOrNull(3) ?: "C"
            binding.optionD.text = questionParts.getOrNull(4) ?: "D"
            correctAns = correctAnswers[questionNo]
        } else {
            finishQuiz()
        }
    }

    private fun handleOptionSelected(answer: String, selectedView: TextView) {
        selectedAns = answer
        resetOptionStyles()
        selectedView.setBackgroundResource(R.color.white) // Change background to indicate selection
        selectedView.setTextColor(resources.getColor(R.color.blue)) // Change text color
    }

    private fun resetOptionStyles() {
        binding.optionA.setBackgroundResource(R.color.blue)
        binding.optionA.setTextColor(resources.getColor(R.color.white))
        binding.optionB.setBackgroundResource(R.color.blue)
        binding.optionB.setTextColor(resources.getColor(R.color.white))
        binding.optionC.setBackgroundResource(R.color.blue)
        binding.optionC.setTextColor(resources.getColor(R.color.white))
        binding.optionD.setBackgroundResource(R.color.blue)
        binding.optionD.setTextColor(resources.getColor(R.color.white))
    }

    private fun checkAnswer() {
        if (selectedAns == correctAns) {
            score++
            FancyToast.makeText(
                this,
                "Jawapan Betul!",
                FancyToast.LENGTH_SHORT,
                FancyToast.SUCCESS,
                false
            ).show()
        } else {
            FancyToast.makeText(
                this,
                "Jawapan Salah!",
                FancyToast.LENGTH_SHORT,
                FancyToast.ERROR,
                false
            ).show()
        }
    }

    private fun loadNextQuestionOrFinish() {
        questionNo++
        if (questionNo < questions.size) {
            showQuestion()
        } else {
            finishQuiz()
        }
    }

    private fun finishQuiz() {
        FancyToast.makeText(
            this,
            "Kuiz Tamat! Skor Anda: $score/${questions.size}",
            FancyToast.LENGTH_LONG,
            FancyToast.INFO,
            false
        ).show()
        val intent = Intent(this, ScoreActivity::class.java)
        intent.putExtra("score", score)
        startActivity(intent)
        finish()
    }
}
