package com.example.quizapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class CreateQuizActivity : AppCompatActivity() {

    // Declare the views
    private lateinit var questionInput: TextInputEditText
    private lateinit var option1Input: TextInputEditText
    private lateinit var option2Input: TextInputEditText
    private lateinit var option3Input: TextInputEditText
    private lateinit var option4Input: TextInputEditText
    private lateinit var correctAnswerSpinner: Spinner
    private lateinit var uploadButton: Button
    private lateinit var cancelButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_quiz)

        // Initialize the views
        questionInput = findViewById(R.id.questionInput)
        option1Input = findViewById(R.id.option1Input)
        option2Input = findViewById(R.id.option2Input)
        option3Input = findViewById(R.id.option3Input)
        option4Input = findViewById(R.id.option4Input)
        correctAnswerSpinner = findViewById(R.id.correctAnswerSpinner)
        uploadButton = findViewById(R.id.uploadButton)
        cancelButton = findViewById(R.id.cancel_button)

        // Set up the spinner
        val options = arrayOf("Pilihan 1", "Pilihan 2", "Pilihan 3", "Pilihan 4")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, options)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        correctAnswerSpinner.adapter = adapter

        // Set click listeners for the buttons
        uploadButton.setOnClickListener {
            handleUpload()
        }

        cancelButton.setOnClickListener {
            clearInputs()
        }
    }

    private fun handleUpload() {
        // Get the inputs from the fields
        val question = questionInput.text.toString().trim()
        val option1 = option1Input.text.toString().trim()
        val option2 = option2Input.text.toString().trim()
        val option3 = option3Input.text.toString().trim()
        val option4 = option4Input.text.toString().trim()
        val correctAnswer = correctAnswerSpinner.selectedItem.toString()

        // Validate the inputs
        if (question.isEmpty() || option1.isEmpty() || option2.isEmpty() || option3.isEmpty() || option4.isEmpty()) {
            Toast.makeText(this, "Sila isi semua medan!", Toast.LENGTH_SHORT).show()
            return
        }

        // Handle the data (e.g., save to database or send to server)
        Toast.makeText(this, "Soalan berjaya dimuat naik!", Toast.LENGTH_SHORT).show()
        // TODO: Add logic to save the quiz data
    }

    private fun clearInputs() {
        // Clear all input fields and reset the spinner
        questionInput.text?.clear()
        option1Input.text?.clear()
        option2Input.text?.clear()
        option3Input.text?.clear()
        option4Input.text?.clear()
        correctAnswerSpinner.setSelection(0)

        Toast.makeText(this, "Input telah dikosongkan.", Toast.LENGTH_SHORT).show()
    }
}
