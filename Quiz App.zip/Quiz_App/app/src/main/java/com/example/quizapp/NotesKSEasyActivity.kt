package com.example.quizapp

import android.view.View
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.quizapp.databinding.ActivityNotesKseasyBinding

class NotesKSEasyActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityNotesKseasyBinding.inflate(layoutInflater)
    }

    private val questionsAndOptions = listOf(
        Triple(
            "1. Apakah maksud kitar semula?",
            listOf(
                "A) Menggunakan semula barangan lama",
                "B) Membakar sisa buangan",
                "C) Mengubah bahan terpakai menjadi produk baharu",
                "D) Membawa barang ke tapak pelupusan"
            ),
            "C"
        ),
        Triple(
            "2. Apakah bahan berikut yang boleh dikitar semula?",
            listOf(
                "A) Plastik, kertas, kaca",
                "B) Plastik, sisa makanan, kayu",
                "C) Batu, pasir, tanah",
                "D) Kaca, seramik, logam berat"
            ),
            "A"
        ),
        Triple(
            "3. Warna tong kitar semula untuk plastik ialah…",
            listOf(
                "A) Hijau",
                "B) Biru",
                "C) Kuning",
                "D) Merah"
            ),
            "C"
        ),
        Triple(
            "4. Simbol kitar semula berbentuk…",
            listOf(
                "A) Segi tiga dengan tiga anak panah",
                "B) Lingkaran dengan satu anak panah",
                "C) Bulatan penuh",
                "D) Segi empat dengan satu anak panah"
            ),
            "A"
        ),
        Triple(
            "5. Apakah bahan yang tidak boleh dikitar semula?",
            listOf(
                "A) Kertas",
                "B) Botol kaca",
                "C) Bekas makanan yang berminyak",
                "D) Tin aluminium"
            ),
            "C"
        ),
        Triple(
            "6. Mengapa penting untuk mengitar semula?",
            listOf(
                "A) Untuk mengurangkan pencemaran dan menjimatkan sumber",
                "B) Untuk meningkatkan pencemaran",
                "C) Untuk menghasilkan lebih banyak sisa",
                "D) Untuk membuang semua barang lama"
            ),
            "A"
        ),
        Triple(
            "7. E-waste merujuk kepada…",
            listOf(
                "A) Sisa elektronik seperti telefon bimbit dan komputer",
                "B) Sisa makanan yang dibuang",
                "C) Sisa daripada kilang",
                "D) Barang terbuang yang besar"
            ),
            "A"
        ),
        Triple(
            "8. Kertas yang boleh dikitar semula ialah…",
            listOf(
                "A) Kertas bersalut minyak",
                "B) Kertas surat khabar lama",
                "C) Kertas yang sangat basah",
                "D) Kertas yang koyak dan kotor"
            ),
            "B"
        ),
        Triple(
            "9. Apakah yang perlu dilakukan dengan sisa plastik sebelum dikitar semula?",
            listOf(
                "A) Campurkan dengan sisa makanan",
                "B) Bakar terlebih dahulu",
                "C) Bersihkan dan asingkan mengikut jenis",
                "D) Masukkan terus ke tong hijau"
            ),
            "C"
        ),
        Triple(
            "10. Proses kitar semula boleh membantu…",
            listOf(
                "A) Mengurangkan penggunaan tenaga",
                "B) Menghasilkan lebih banyak sampah",
                "C) Mengurangkan penghasilan produk baharu",
                "D) Menghapuskan sumber alam sepenuhnya"
            ),
            "A"
        )
    )

    private var currentQuestionIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        displayQuestion()

        binding.option1Button.setOnClickListener { checkAnswer("A") }
        binding.option2Button.setOnClickListener { checkAnswer("B") }
        binding.option3Button.setOnClickListener { checkAnswer("C") }
        binding.option4Button.setOnClickListener { checkAnswer("D") }

        binding.nextButton.setOnClickListener {
            loadNextQuestion()
        }
    }

    private fun displayQuestion() {
        if (currentQuestionIndex < questionsAndOptions.size) {
            val (question, options, _) = questionsAndOptions[currentQuestionIndex]
            binding.questionPlaceholder.text = question
            binding.option1Button.text = options[0]
            binding.option2Button.text = options[1]
            binding.option3Button.text = options[2]
            binding.option4Button.text = options[3]
            enableOptionButtons() // Ensure option buttons are enabled for the next question
        } else {
            binding.questionPlaceholder.text = "Ulangkaji tamat!"
            disableOptionButtons()
            binding.nextButton.isEnabled = false // Disable the Next button when the quiz ends
            showHomeButton()
        }
    }

    private fun checkAnswer(selectedAnswer: String) {
        val (_, _, correctAnswer) = questionsAndOptions[currentQuestionIndex]
        if (selectedAnswer == correctAnswer) {
            Toast.makeText(this, "Jawapan betul!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Jawapan salah! Jawapan betul: $correctAnswer", Toast.LENGTH_SHORT)
                .show()
        }
        disableOptionButtons() // Disable option buttons after answering
    }

    private fun loadNextQuestion() {
        if (currentQuestionIndex < questionsAndOptions.size - 1) {
            currentQuestionIndex++
            displayQuestion()
        } else {
            Toast.makeText(this, "Ulangkaji tamat!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun disableOptionButtons() {
        binding.option1Button.isEnabled = false
        binding.option2Button.isEnabled = false
        binding.option3Button.isEnabled = false
        binding.option4Button.isEnabled = false
    }

    private fun enableOptionButtons() {
        binding.option1Button.isEnabled = true
        binding.option2Button.isEnabled = true
        binding.option3Button.isEnabled = true
        binding.option4Button.isEnabled = true
    }

    private fun showHomeButton() {
        binding.homeButton.apply {
            text = "Halaman Utama"
            isEnabled = true
            visibility = View.VISIBLE
            setOnClickListener {
                // Navigate to home page
                val intent = Intent(this@NotesKSEasyActivity, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}