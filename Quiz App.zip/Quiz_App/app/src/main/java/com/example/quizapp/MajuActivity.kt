package com.example.quizapp

import android.view.View
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.quizapp.databinding.ActivityMajuBinding

class MajuActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityMajuBinding.inflate(layoutInflater)
    }

    private val questionsAndOptions = listOf(
        Triple(
            "1. Apakah maksud ‘ekonomi kitaran’?",
            listOf(
                "A) Menghasilkan lebih banyak produk baharu menggunakan bahan mentah",
                "B) Mengitar semula sepenuhnya dan menghapuskan sisa dengan menggunakan semula bahan mentah",
                "C) Meningkatkan penggunaan tenaga daripada sumber fosil",
                "D) Membakar semua bahan sisa untuk menghapuskan pencemaran"
            ),
            "B"
        ),
        Triple(
            "2. Apakah cabaran utama kitar semula sisa elektronik di Malaysia?",
            listOf(
                "A) Kekurangan tapak pelupusan sisa elektronik",
                "B) Tidak cukup teknologi untuk memproses sisa elektronik",
                "C) Kos logistik dan pengumpulan e-waste yang tinggi",
                "D) Tiada dasar kerajaan untuk sisa elektronik"
            ),
            "C"
        ),
        Triple(
            "3. Apakah perbezaan utama antara kitar semula kimia dan mekanikal untuk plastik?",
            listOf(
                "A) Kitar semula kimia lebih murah daripada mekanikal",
                "B) Kitar semula kimia melibatkan pemecahan struktur molekul plastik",
                "C) Kitar semula mekanikal hanya boleh dilakukan pada kaca",
                "D) Kitar semula kimia tidak memerlukan teknologi tinggi"
            ),
            "B"
        ),
        Triple(
            "4. Bagaimanakah AI dapat meningkatkan kadar kitar semula?",
            listOf(
                "A) Menghapuskan bahan mentah yang tidak boleh dikitar semula",
                "B) Automasi pengasingan bahan di pusat kitar semula",
                "C) Menggantikan tenaga manusia dengan robot sepenuhnya",
                "D) Mengurangkan kadar pengeluaran produk baharu"
            ),
            "B"
        ),
        Triple(
            "5. Apakah yang dimaksudkan dengan ‘upcycling’?",
            listOf(
                "A) Proses kitar semula bahan menjadi produk dengan nilai yang lebih tinggi",
                "B) Proses mengurangkan sisa dengan membakarnya",
                "C) Proses menggunakan sisa untuk menghasilkan tenaga",
                "D) Proses kitar semula produk menjadi bahan mentah semula"
            ),
            "A"
        ),
        Triple(
            "6. Apakah inovasi terkini yang digunakan untuk memproses sisa plastik campuran?",
            listOf(
                "A) Pembakaran sisa plastik",
                "B) Kitar semula kimia",
                "C) Penimbunan sisa di tapak pelupusan",
                "D) Pemanasan plastik tanpa oksigen"
            ),
            "B"
        ),
        Triple(
            "7. Apakah kesan ekonomi daripada peningkatan kadar kitar semula global?",
            listOf(
                "A) Pengurangan kos tenaga buruh",
                "B) Peningkatan peluang pekerjaan dalam industri hijau",
                "C) Menghapuskan semua industri minyak dan gas",
                "D) Pengurangan hasil eksport negara"
            ),
            "B"
        ),
        Triple(
            "8. Apakah maksud ‘cradle to cradle’ dalam pengurusan produk?",
            listOf(
                "A) Konsep kitaran di mana semua bahan dalam produk boleh digunakan semula atau dikitar semula tanpa meninggalkan sisa",
                "B) Menggunakan bahan mentah baharu bagi setiap kitaran pengeluaran",
                "C) Mengurangkan penggunaan sumber semula jadi tetapi membuang sisa ke tapak pelupusan",
                "D) Menghapuskan penggunaan teknologi dalam pembuatan produk"
            ),
            "A"
        ),
        Triple(
            "9. Mengapa penting untuk memisahkan sisa organik daripada bahan kitar semula?",
            listOf(
                "A) Untuk meningkatkan kadar pencemaran udara",
                "B) Untuk memaksimumkan kadar kitar semula bahan tidak organik",
                "C) Untuk menghapuskan semua bahan mentah",
                "D) Untuk menghasilkan lebih banyak sisa di tapak pelupusan"
            ),
            "B"
        ),
        Triple(
            "10. Apakah peranan dasar Extended Producer Responsibility (EPR)?",
            listOf(
                "A) Menghapuskan tanggungjawab syarikat terhadap produk mereka",
                "B) Menjadikan pengilang bertanggungjawab terhadap pelupusan produk yang mereka hasilkan",
                "C) Memberikan insentif kepada pengguna untuk membuang sisa",
                "D) Menggalakkan pembakaran bahan sisa berbahaya"
            ),
            "B"
        )
    )

    private var currentQuestionIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        displayQuestion()

        binding.option1Button.setOnClickListener { checkAnswer("A") }
        binding.option2Button.setOnClickListener { checkAnswer("B") }
        binding.option3Button.setOnClickListener { checkAnswer("C") }
        binding.option4Button.setOnClickListener { checkAnswer("D") }

        binding.nextButton.setOnClickListener {
            loadNextQuestion()
        }
    }

    private fun displayQuestion() {
        if (currentQuestionIndex < questionsAndOptions.size) {
            val (question, options, _) = questionsAndOptions[currentQuestionIndex]
            binding.questionPlaceholder.text = question
            binding.option1Button.text = options[0]
            binding.option2Button.text = options[1]
            binding.option3Button.text = options[2]
            binding.option4Button.text = options[3]
            enableOptionButtons()
        } else {
            binding.questionPlaceholder.text = "Ulangkaji tamat!"
            disableOptionButtons()
            binding.nextButton.isEnabled = false
            showHomeButton()
        }
    }

    private fun checkAnswer(selectedAnswer: String) {
        val (_, _, correctAnswer) = questionsAndOptions[currentQuestionIndex]
        if (selectedAnswer == correctAnswer) {
            Toast.makeText(this, "Jawapan betul!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Jawapan salah! Jawapan betul: $correctAnswer", Toast.LENGTH_SHORT)
                .show()
        }
        disableOptionButtons()
    }

    private fun loadNextQuestion() {
        if (currentQuestionIndex < questionsAndOptions.size - 1) {
            currentQuestionIndex++
            displayQuestion()
        } else {
            Toast.makeText(this, "Ulangkaji tamat!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun disableOptionButtons() {
        binding.option1Button.isEnabled = false
        binding.option2Button.isEnabled = false
        binding.option3Button.isEnabled = false
        binding.option4Button.isEnabled = false
    }

    private fun enableOptionButtons() {
        binding.option1Button.isEnabled = true
        binding.option2Button.isEnabled = true
        binding.option3Button.isEnabled = true
        binding.option4Button.isEnabled = true
    }

    private fun showHomeButton() {
        binding.homeButton.apply {
            text = "Halaman Utama"
            isEnabled = true
            visibility = View.VISIBLE
            setOnClickListener {
                val intent = Intent(this@MajuActivity, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}
