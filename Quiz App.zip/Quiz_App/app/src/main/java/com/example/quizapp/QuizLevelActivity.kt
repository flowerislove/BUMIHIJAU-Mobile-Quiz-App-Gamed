package com.example.quizapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class QuizLevelActivity : AppCompatActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_level)

        val buttonPemula: Button = findViewById(R.id.buttonPemula)
        val buttonSederhana: Button = findViewById(R.id.buttonSederhana)
        val buttonMaju: Button = findViewById(R.id.buttonMaju)

        buttonPemula.setOnClickListener(this)
        buttonSederhana.setOnClickListener(this)
        buttonMaju.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        val level = when (v?.id) {
            R.id.buttonPemula -> "Pemula"
            R.id.buttonSederhana -> "Sederhana"
            R.id.buttonMaju -> "Maju"
            else -> ""
        }

        if (level.isNotEmpty()) {
            val intent = Intent(this, QuizpageActivity::class.java)
            intent.putExtra("QUIZ_LEVEL", level)
            startActivity(intent)
        }
    }
}
