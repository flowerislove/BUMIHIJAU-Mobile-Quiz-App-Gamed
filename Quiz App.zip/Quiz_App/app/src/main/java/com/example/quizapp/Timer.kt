package com.example.quizapp

import android.os.CountDownTimer
import android.widget.TextView

class Timer(
    totalTime: Long,
    interval: Long,
    private val timerTextView: TextView, // Directly take the TextView as a parameter
    private val onTimerFinish: () -> Unit // Callback function when the timer finishes
) : CountDownTimer(totalTime, interval) {

    override fun onTick(millisUntilFinished: Long) {
        val secondsLeft = millisUntilFinished / 1000
        timerTextView.text = secondsLeft.toString() // Display remaining seconds
    }

    override fun onFinish() {
        onTimerFinish() // Call the callback function when the timer finishes
    }
}
