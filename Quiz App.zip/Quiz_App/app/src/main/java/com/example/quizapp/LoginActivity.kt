package com.example.quizapp

import android.content.Intent
import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.KeyEvent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.lifecycleScope
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.quizapp.databinding.ActivityLoginBinding
import com.example.quizapp.databinding.SetNameDialogBinding
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.shashank.sony.fancytoastlib.FancyToast
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    private val binding by lazy { ActivityLoginBinding.inflate(layoutInflater) }
    private lateinit var auth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        setupUIInsets()

        auth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().reference

        setupLogin()
        setupPasswordToggle()
        setupRegisterButton()
        setupForgotPasswordButton()
        setupGoogleSignIn()
    }

    private fun setupUIInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun setupLogin() {
        binding.loginButton2.setOnClickListener {
            val email = binding.emailEditText2.text.toString().trim()
            val password = binding.passwordEditText2.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                showToast("Incomplete credentials", FancyToast.WARNING)
            } else {
                auth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener {
                        val user = auth.currentUser
                        if (user?.isEmailVerified == true) {
                            showToast("Login Successful", FancyToast.SUCCESS)
                            navigateToMainActivity()
                        } else {
                            showToast("Email not verified", FancyToast.ERROR)
                            auth.signOut()
                        }
                    }
                    .addOnFailureListener { e ->
                        showToast("Error: ${e.message}", FancyToast.ERROR)
                    }
            }
        }
    }

    private fun setupPasswordToggle() {
        binding.viewPasswordButton2.setOnClickListener {
            val editText = binding.passwordEditText2
            val isPasswordVisible =
                editText.transformationMethod !is PasswordTransformationMethod

            editText.transformationMethod = if (isPasswordVisible) {
                PasswordTransformationMethod.getInstance()
            } else {
                null
            }

            val iconRes = if (isPasswordVisible) {
                R.drawable.show_password
            } else {
                R.drawable.hide_password
            }
            binding.viewPasswordButton2.setImageResource(iconRes)
            editText.setSelection(editText.length())
        }
    }

    private fun setupRegisterButton() {
        binding.registerButton2.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
            finish()
        }
    }

    private fun setupForgotPasswordButton() {
        binding.forgotPasswordButton.setOnClickListener {
            startActivity(Intent(this, ForgotPasswordActivity::class.java))
        }
    }

    private fun setupGoogleSignIn() {
        binding.googleSignInButton.setOnClickListener {
            val webClientId = getString(R.string.web_client_id)
            val signInOption = GetSignInWithGoogleOption.Builder(webClientId).build()
            val request = GetCredentialRequest(listOf(signInOption))
            val credentialManager = CredentialManager.create(this)

            lifecycleScope.launch {
                try {
                    val result = credentialManager.getCredential(this@LoginActivity, request)
                    handleSignIn(result)
                } catch (e: GetCredentialException) {
                    Log.e("GoogleSignIn", "Error: ${e.message}", e)
                }
            }
        }
    }

    private fun handleSignIn(result: GetCredentialResponse) {
        when (val credential = result.credential) {
            is CustomCredential -> {
                if (credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    try {
                        val idToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                        firebaseSignInWithGoogle(idToken)
                    } catch (e: GoogleIdTokenParsingException) {
                        Log.e("GoogleSignIn", "Invalid Google ID Token", e)
                    }
                } else {
                    Log.e("GoogleSignIn", "Unexpected credential type")
                }
            }

            else -> {
                Log.e("GoogleSignIn", "Unexpected credential type")
            }
        }
    }

    private fun firebaseSignInWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnSuccessListener {
                checkIfNewUser()
            }
            .addOnFailureListener { e ->
                Log.e("GoogleSignIn", "Sign-in failed", e)
            }
    }

    private fun checkIfNewUser() {
        val user = auth.currentUser ?: return
        databaseReference.child("users").child(user.uid).child("name")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (!snapshot.exists()) {
                        showSetNameDialog(user.uid)
                    } else {
                        navigateToMainActivity()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("DatabaseError", error.message, error.toException())
                }
            })
    }

    private fun showSetNameDialog(userId: String) {
        val dialogBinding = SetNameDialogBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setCancelable(false)
            .create()
        dialog.show()

        dialogBinding.saveButton.setOnClickListener {
            val name = dialogBinding.nameEditText2.text.toString().trim()
            if (name.isEmpty()) {
                showToast("Empty name", FancyToast.ERROR)
            } else {
                databaseReference.child("users").child(userId).setValue(DataModel(name, 0))
                dialog.dismiss()
                navigateToMainActivity()
            }
        }
    }

    private fun navigateToMainActivity() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun showToast(message: String, type: Int) {
        FancyToast.makeText(this, message, FancyToast.LENGTH_SHORT, type, false).show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            startActivity(Intent(this, AuthenticationScreen::class.java))
            finishAffinity()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
