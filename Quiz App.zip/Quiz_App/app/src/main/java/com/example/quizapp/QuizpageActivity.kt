package com.example.quizapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class QuizpageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quizpage)

        // Get the QUIZ_LEVEL from Intent
        val level = intent.getStringExtra("QUIZ_LEVEL") ?: ""

        // Initialize buttons
        val buttonKitarSemula: Button = findViewById(R.id.buttonKitarSemula)
        val buttonEWaste: Button = findViewById(R.id.buttonEWaste)
        val buttonAdd: Button = findViewById(R.id.buttonAdd)

        // Set click listeners for buttons
        buttonKitarSemula.setOnClickListener {
            handleCategoryButtonClick("KitarSemula", level)
        }

        buttonEWaste.setOnClickListener {
            handleCategoryButtonClick("EWaste", level)
        }

        buttonAdd.setOnClickListener {
            // Navigate to CreateQuizActivity
            val intent = Intent(this, CreateQuizActivity::class.java)
            intent.putExtra("QUIZ_LEVEL", level) // Optional, pass level if needed
            startActivity(intent)
        }
    }

    private fun handleCategoryButtonClick(category: String, level: String) {
        val intent = when (level) {
            "Pemula" -> Intent(this, QuestionActivity::class.java).apply {
                putExtra("QUIZ_LEVEL", level)
                putExtra("CATEGORY", category)
            }
            "Sederhana" -> {
                if (category == "KitarSemula") Intent(this, KSMediumQuizActivity::class.java)
                else Intent(this, EWasteMediumQuizActivity::class.java)
            }
            "Maju" -> {
                if (category == "KitarSemula") Intent(this, KSAdvancedQuizActivity::class.java)
                else Intent(this, EWasteAdvancedQuizActivity::class.java)
            }
            else -> null
        }
        intent?.let { startActivity(it) }
    }
}
