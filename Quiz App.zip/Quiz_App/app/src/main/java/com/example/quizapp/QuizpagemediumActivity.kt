package com.example.quizapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class QuizpagemediumActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quizpagemedium)

        // Get the QUIZ_LEVEL from the Intent
        val level = intent.getStringExtra("QUIZ_LEVEL") ?: ""

        // Initialize buttons
        val buttonKitarSemula: Button = findViewById(R.id.buttonKitarSemula)
        val buttonEWaste: Button = findViewById(R.id.buttonEWaste)
        val buttonAdd: Button = findViewById(R.id.buttonAdd)

        // Set click listeners for each button
        buttonKitarSemula.setOnClickListener {
            // Navigate to Kitar Semula quiz page or perform desired action
            val intent = Intent(this, KSMediumQuizActivity::class.java)
            intent.putExtra("QUIZ_LEVEL", level)
            startActivity(intent)
        }

        buttonEWaste.setOnClickListener {
            // Navigate to E-Waste quiz page or perform desired action
            val intent = Intent(this, EWasteMediumQuizActivity::class.java)
            intent.putExtra("QUIZ_LEVEL", "E-Waste")
            startActivity(intent)
        }

        buttonAdd.setOnClickListener {
            // Navigate to Add Question page or perform desired action
            val intent = Intent(this, CreateQuizActivity::class.java)
            startActivity(intent)
        }
    }
}
