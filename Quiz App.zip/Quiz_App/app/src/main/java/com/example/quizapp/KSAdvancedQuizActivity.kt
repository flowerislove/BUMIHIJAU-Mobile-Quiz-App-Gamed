package com.example.quizapp

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.quizapp.databinding.ActivityKsadvancedQuizBinding
import com.shashank.sony.fancytoastlib.FancyToast

class KSAdvancedQuizActivity : AppCompatActivity() {
    private lateinit var binding: ActivityKsadvancedQuizBinding

    private var selectedAns: String = ""
    private var correctAns: String = ""
    private var questionNo = 0
    private var score = 0

    // Updated list of questions (Advanced Level)
    private val questions = listOf(
        "1. Apakah maksud ‘ekonomi kitaran’?\nA) Menghasilkan lebih banyak produk baharu menggunakan bahan mentah\nB) Mengitar semula sepenuhnya dan menghapuskan sisa dengan menggunakan semula bahan mentah\nC) Meningkatkan penggunaan tenaga daripada sumber fosil\nD) Membakar semua bahan sisa untuk menghapuskan pencemaran",
        "2. Apakah cabaran utama kitar semula sisa elektronik di Malaysia?\nA) Kekurangan tapak pelupusan sisa elektronik\nB) Tidak cukup teknologi untuk memproses sisa elektronik\nC) Kos logistik dan pengumpulan e-waste yang tinggi\nD) Tiada dasar kerajaan untuk sisa elektronik",
        "3. Apakah perbezaan utama antara kitar semula kimia dan mekanikal untuk plastik?\nA) Kitar semula kimia lebih murah daripada mekanikal\nB) Kitar semula kimia melibatkan pemecahan struktur molekul plastik\nC) Kitar semula mekanikal hanya boleh dilakukan pada kaca\nD) Kitar semula kimia tidak memerlukan teknologi tinggi",
        "4. Bagaimanakah AI dapat meningkatkan kadar kitar semula?\nA) Menghapuskan bahan mentah yang tidak boleh dikitar semula\nB) Automasi pengasingan bahan di pusat kitar semula\nC) Menggantikan tenaga manusia dengan robot sepenuhnya\nD) Mengurangkan kadar pengeluaran produk baharu",
        "5. Apakah yang dimaksudkan dengan ‘upcycling’?\nA) Proses kitar semula bahan menjadi produk dengan nilai yang lebih tinggi\nB) Proses mengurangkan sisa dengan membakarnya\nC) Proses menggunakan sisa untuk menghasilkan tenaga\nD) Proses kitar semula produk menjadi bahan mentah semula",
        "6. Apakah inovasi terkini yang digunakan untuk memproses sisa plastik campuran?\nA) Pembakaran sisa plastik\nB) Kitar semula kimia\nC) Penimbunan sisa di tapak pelupusan\nD) Pemanasan plastik tanpa oksigen",
        "7. Apakah kesan ekonomi daripada peningkatan kadar kitar semula global?\nA) Pengurangan kos tenaga buruh\nB) Peningkatan peluang pekerjaan dalam industri hijau\nC) Menghapuskan semua industri minyak dan gas\nD) Pengurangan hasil eksport negara",
        "8. Apakah maksud ‘cradle to cradle’ dalam pengurusan produk?\nA) Konsep kitaran di mana semua bahan dalam produk boleh digunakan semula atau dikitar semula tanpa meninggalkan sisa\nB) Menggunakan bahan mentah baharu bagi setiap kitaran pengeluaran\nC) Mengurangkan penggunaan sumber semula jadi tetapi membuang sisa ke tapak pelupusan\nD) Menghapuskan penggunaan teknologi dalam pembuatan produk",
        "9. Mengapa penting untuk memisahkan sisa organik daripada bahan kitar semula?\nA) Untuk meningkatkan kadar pencemaran udara\nB) Untuk memaksimumkan kadar kitar semula bahan tidak organik\nC) Untuk menghapuskan semua bahan mentah\nD) Untuk menghasilkan lebih banyak sisa di tapak pelupusan",
        "10. Apakah peranan dasar Extended Producer Responsibility (EPR)?\nA) Menghapuskan tanggungjawab syarikat terhadap produk mereka\nB) Menjadikan pengilang bertanggungjawab terhadap pelupusan produk yang mereka hasilkan\nC) Memberikan insentif kepada pengguna untuk membuang sisa\nD) Menggalakkan pembakaran bahan sisa berbahaya"
    )

    // Updated list of correct answers
    private val correctAnswers = listOf("B", "C", "B", "B", "A", "B", "B", "A", "B", "B")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityKsadvancedQuizBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showQuestion()

        binding.optionA.setOnClickListener { handleOptionSelected("A", binding.optionA) }
        binding.optionB.setOnClickListener { handleOptionSelected("B", binding.optionB) }
        binding.optionC.setOnClickListener { handleOptionSelected("C", binding.optionC) }
        binding.optionD.setOnClickListener { handleOptionSelected("D", binding.optionD) }

        binding.nextQuestionButton.setOnClickListener {
            if (selectedAns.isEmpty()) {
                FancyToast.makeText(
                    this,
                    "Sila pilih jawapan",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.INFO,
                    false
                ).show()
            } else {
                checkAnswer()
                loadNextQuestionOrFinish()
            }
        }
    }

    private fun showQuestion() {
        if (questionNo < questions.size) {
            val questionParts = questions[questionNo].split("\n")
            binding.question.text = questionParts[0] // Question text
            binding.optionA.text = questionParts.getOrNull(1) ?: "A"
            binding.optionB.text = questionParts.getOrNull(2) ?: "B"
            binding.optionC.text = questionParts.getOrNull(3) ?: "C"
            binding.optionD.text = questionParts.getOrNull(4) ?: "D"
            correctAns = correctAnswers[questionNo]
        } else {
            finishQuiz()
        }
    }

    private fun handleOptionSelected(answer: String, selectedView: TextView) {
        selectedAns = answer
        resetOptionStyles()
        selectedView.setBackgroundResource(R.color.white) // Change background to indicate selection
        selectedView.setTextColor(resources.getColor(R.color.blue)) // Change text color
    }

    private fun resetOptionStyles() {
        binding.optionA.setBackgroundResource(R.color.blue)
        binding.optionA.setTextColor(resources.getColor(R.color.white))
        binding.optionB.setBackgroundResource(R.color.blue)
        binding.optionB.setTextColor(resources.getColor(R.color.white))
        binding.optionC.setBackgroundResource(R.color.blue)
        binding.optionC.setTextColor(resources.getColor(R.color.white))
        binding.optionD.setBackgroundResource(R.color.blue)
        binding.optionD.setTextColor(resources.getColor(R.color.white))
    }

    private fun checkAnswer() {
        if (selectedAns == correctAns) {
            score++
            FancyToast.makeText(
                this,
                "Jawapan Betul!",
                FancyToast.LENGTH_SHORT,
                FancyToast.SUCCESS,
                false
            ).show()
        } else {
            FancyToast.makeText(
                this,
                "Jawapan Salah!",
                FancyToast.LENGTH_SHORT,
                FancyToast.ERROR,
                false
            ).show()
        }
    }

    private fun loadNextQuestionOrFinish() {
        questionNo++
        if (questionNo < questions.size) {
            showQuestion()
        } else {
            finishQuiz()
        }
    }

    private fun finishQuiz() {
        FancyToast.makeText(
            this,
            "Kuiz Tamat! Skor Anda: $score/${questions.size}",
            FancyToast.LENGTH_LONG,
            FancyToast.INFO,
            false
        ).show()
        val intent = Intent(this, ScoreActivity::class.java)
        intent.putExtra("score", score)
        startActivity(intent)
        finish()
    }
}
