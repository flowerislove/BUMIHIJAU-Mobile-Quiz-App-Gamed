package com.example.quizapp

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.quizapp.databinding.ActivityEwasteMediumQuizBinding
import com.shashank.sony.fancytoastlib.FancyToast

class EWasteMediumQuizActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEwasteMediumQuizBinding

    private var selectedAns: String = ""
    private var correctAns: String = ""
    private var questionNo = 0
    private var score = 0

    // Full list of questions
    private val questions = listOf(
        "1. Apakah bahan berharga yang boleh diperoleh daripada e-waste?\nA) Kayu dan plastik\nB) Emas, tembaga, paladium, dan perak\nC) Kain dan kertas\nD) Minyak dan gas",
        "2. Apakah kesan negatif jika e-waste tidak diurus dengan betul?\nA) Peningkatan populasi haiwan liar\nB) Pencemaran udara, tanah, dan air akibat pelepasan bahan toksik\nC) Pertumbuhan tumbuhan yang lebih cepat\nD) Penurunan suhu global",
        "3. Apakah aplikasi mudah alih yang dilancarkan oleh Jabatan Alam Sekitar Malaysia untuk memudahkan penghantaran e-waste?\nA) MyRecycle\nB) MyEwaste\nC) RecycleNow\nD) EwasteApp"
    )

    // Full list of correct answers
    private val correctAnswers = listOf("B", "B", "B")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEwasteMediumQuizBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showQuestion()

        binding.optionA.setOnClickListener { handleOptionSelected("A", binding.optionA) }
        binding.optionB.setOnClickListener { handleOptionSelected("B", binding.optionB) }
        binding.optionC.setOnClickListener { handleOptionSelected("C", binding.optionC) }
        binding.optionD.setOnClickListener { handleOptionSelected("D", binding.optionD) }

        binding.nextQuestionButton.setOnClickListener {
            if (selectedAns.isEmpty()) {
                FancyToast.makeText(
                    this,
                    "Sila pilih jawapan",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.INFO,
                    false
                ).show()
            } else {
                checkAnswer()
                loadNextQuestionOrFinish()
            }
        }
    }

    private fun showQuestion() {
        if (questionNo < questions.size) {
            val questionParts = questions[questionNo].split("\n")
            binding.question.text = questionParts[0] // Question text
            binding.optionA.text = questionParts.getOrNull(1) ?: "A"
            binding.optionB.text = questionParts.getOrNull(2) ?: "B"
            binding.optionC.text = questionParts.getOrNull(3) ?: "C"
            binding.optionD.text = questionParts.getOrNull(4) ?: "D"
            correctAns = correctAnswers[questionNo]
        } else {
            finishQuiz()
        }
    }

    private fun handleOptionSelected(answer: String, selectedView: TextView) {
        selectedAns = answer
        resetOptionStyles()
        selectedView.setBackgroundResource(R.color.white) // Change background to indicate selection
        selectedView.setTextColor(resources.getColor(R.color.blue)) // Change text color
    }

    private fun resetOptionStyles() {
        binding.optionA.setBackgroundResource(R.color.blue)
        binding.optionA.setTextColor(resources.getColor(R.color.white))
        binding.optionB.setBackgroundResource(R.color.blue)
        binding.optionB.setTextColor(resources.getColor(R.color.white))
        binding.optionC.setBackgroundResource(R.color.blue)
        binding.optionC.setTextColor(resources.getColor(R.color.white))
        binding.optionD.setBackgroundResource(R.color.blue)
        binding.optionD.setTextColor(resources.getColor(R.color.white))
    }

    private fun checkAnswer() {
        if (selectedAns == correctAns) {
            score++
            FancyToast.makeText(
                this,
                "Jawapan Betul!",
                FancyToast.LENGTH_SHORT,
                FancyToast.SUCCESS,
                false
            ).show()
        } else {
            FancyToast.makeText(
                this,
                "Jawapan Salah!",
                FancyToast.LENGTH_SHORT,
                FancyToast.ERROR,
                false
            ).show()
        }
    }

    private fun loadNextQuestionOrFinish() {
        questionNo++
        if (questionNo < questions.size) {
            showQuestion()
        } else {
            finishQuiz()
        }
    }

    private fun finishQuiz() {
        FancyToast.makeText(
            this,
            "Kuiz Tamat! Skor Anda: $score/${questions.size}",
            FancyToast.LENGTH_LONG,
            FancyToast.INFO,
            false
        ).show()
        val intent = Intent(this, ScoreActivity::class.java)
        intent.putExtra("score", score)
        startActivity(intent)
        finish()
    }
}
