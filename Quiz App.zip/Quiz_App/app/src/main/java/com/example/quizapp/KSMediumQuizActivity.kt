package com.example.quizapp

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.quizapp.databinding.ActivityKsmediumQuizBinding
import com.shashank.sony.fancytoastlib.FancyToast

class KSMediumQuizActivity : AppCompatActivity() {
    private lateinit var binding: ActivityKsmediumQuizBinding

    private var selectedAns: String = ""
    private var correctAns: String = ""
    private var questionNo = 0
    private var score = 0

    // Full list of questions
    private val questions = listOf(
        "1. Apakah proses pertama dalam kitar semula kaca?\nA) Meleburkan kaca\nB) Mengasingkan kaca mengikut warna\nC) Membakar kaca\nD) Menyusun kaca di kilang",
        "2. Apakah bahan mentah yang dapat dijimatkan melalui kitar semula kertas?\nA) Minyak\nB) Pasir\nC) Kayu\nD) Plastik",
        "3. Mengapa aluminium penting untuk dikitar semula?\nA) Untuk mengurangkan pencemaran air\nB) Untuk menjimatkan tenaga berbanding menghasilkan aluminium baharu\nC) Untuk mencipta produk yang lebih besar\nD) Untuk menghapuskan sisa elektronik",
        "4. Apakah maksud ‘downcycling’?\nA) Proses mengitar semula bahan kepada produk berkualiti lebih rendah\nB) Proses menjadikan bahan kitar semula lebih berkualiti\nC) Menghapuskan bahan sisa secara kekal\nD) Menggabungkan semua bahan kitar semula",
        "5. Apakah peranan utama pusat kitar semula?\nA) Membakar semua sisa buangan\nB) Mengumpulkan dan mengasingkan sisa kitar semula\nC) Mengurangkan tenaga manusia\nD) Menghasilkan lebih banyak sisa",
        "6. Apakah kesan positif kitar semula terhadap alam sekitar?\nA) Menambah pencemaran udara\nB) Mengurangkan penggunaan bahan mentah baharu\nC) Meningkatkan penggunaan tenaga\nD) Menghapuskan tumbuhan hijau",
        "7. Bagaimanakah sisa elektronik dikitar semula?\nA) Dengan membuangnya ke laut\nB) Dengan menanam di dalam tanah\nC) Dengan memisahkan komponen logam berharga\nD) Dengan mencairkan semua bahagian plastik",
        "8. Bahan yang dikitar semula kepada produk baharu berkualiti tinggi dipanggil…\nA) Downcycling\nB) Upcycling\nC) Landfilling\nD) Incinerating",
        "9. Apakah bahan yang sukar dikitar semula?\nA) Botol kaca jernih\nB) Polistirena (Styrofoam)\nC) Tin aluminium\nD) Kertas surat khabar",
        "10. Apakah maksud ‘recovery’ dalam sistem pengurusan sisa?\nA) Menggunakan sisa sebagai tenaga atau bahan mentah baharu\nB) Membakar semua sisa yang tidak berguna\nC) Mengumpulkan sisa buangan di tapak pelupusan\nD) Membiarkan sisa terbiar"
    )

    // Full list of correct answers
    private val correctAnswers = listOf("B", "C", "B", "A", "B", "B", "C", "B", "B", "A")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityKsmediumQuizBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showQuestion()

        binding.optionA.setOnClickListener { handleOptionSelected("A", binding.optionA) }
        binding.optionB.setOnClickListener { handleOptionSelected("B", binding.optionB) }
        binding.optionC.setOnClickListener { handleOptionSelected("C", binding.optionC) }
        binding.optionD.setOnClickListener { handleOptionSelected("D", binding.optionD) }

        binding.nextQuestionButton.setOnClickListener {
            if (selectedAns.isEmpty()) {
                FancyToast.makeText(
                    this,
                    "Sila pilih jawapan",
                    FancyToast.LENGTH_SHORT,
                    FancyToast.INFO,
                    false
                ).show()
            } else {
                checkAnswer()
                loadNextQuestionOrFinish()
            }
        }
    }

    private fun showQuestion() {
        if (questionNo < questions.size) {
            val questionParts = questions[questionNo].split("\n")
            binding.question.text = questionParts[0] // Question text
            binding.optionA.text = questionParts.getOrNull(1) ?: "A"
            binding.optionB.text = questionParts.getOrNull(2) ?: "B"
            binding.optionC.text = questionParts.getOrNull(3) ?: "C"
            binding.optionD.text = questionParts.getOrNull(4) ?: "D"
            correctAns = correctAnswers[questionNo]
        } else {
            finishQuiz()
        }
    }

    private fun handleOptionSelected(answer: String, selectedView: TextView) {
        selectedAns = answer
        resetOptionStyles()
        selectedView.setBackgroundResource(R.color.white) // Change background to indicate selection
        selectedView.setTextColor(resources.getColor(R.color.blue)) // Change text color
    }

    private fun resetOptionStyles() {
        binding.optionA.setBackgroundResource(R.color.blue)
        binding.optionA.setTextColor(resources.getColor(R.color.white))
        binding.optionB.setBackgroundResource(R.color.blue)
        binding.optionB.setTextColor(resources.getColor(R.color.white))
        binding.optionC.setBackgroundResource(R.color.blue)
        binding.optionC.setTextColor(resources.getColor(R.color.white))
        binding.optionD.setBackgroundResource(R.color.blue)
        binding.optionD.setTextColor(resources.getColor(R.color.white))
    }

    private fun checkAnswer() {
        if (selectedAns == correctAns) {
            score++
            FancyToast.makeText(
                this,
                "Jawapan Betul!",
                FancyToast.LENGTH_SHORT,
                FancyToast.SUCCESS,
                false
            ).show()
        } else {
            FancyToast.makeText(
                this,
                "Jawapan Salah!",
                FancyToast.LENGTH_SHORT,
                FancyToast.ERROR,
                false
            ).show()
        }
    }

    private fun loadNextQuestionOrFinish() {
        questionNo++
        if (questionNo < questions.size) {
            showQuestion()
        } else {
            finishQuiz()
        }
    }

    private fun finishQuiz() {
        FancyToast.makeText(
            this,
            "Kuiz Tamat! Skor Anda: $score/${questions.size}",
            FancyToast.LENGTH_LONG,
            FancyToast.INFO,
            false
        ).show()
        val intent = Intent(this, ScoreActivity::class.java)
        intent.putExtra("score", score)
        startActivity(intent)
        finish()
    }
}
