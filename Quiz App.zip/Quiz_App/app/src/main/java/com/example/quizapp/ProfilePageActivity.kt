package com.example.quizapp

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class ProfilePageActivity : AppCompatActivity() {

    private lateinit var profileImageView: ImageView
    private lateinit var nameEditText: EditText
    private lateinit var bioEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var updateButton: Button
    private lateinit var homeButton: Button
    private lateinit var uploadImageButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_page)

        // Initialize views
        profileImageView = findViewById(R.id.profileImageView)
        nameEditText = findViewById(R.id.nameEditText)
        bioEditText = findViewById(R.id.bioEditText)
        emailEditText = findViewById(R.id.emailEditText)
        updateButton = findViewById(R.id.updateButton)
        homeButton = findViewById(R.id.homeButton)  // Halaman Utama button
        uploadImageButton = findViewById(R.id.uploadImageButton)

        // Set up click listener for the update button
        updateButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val bio = bioEditText.text.toString()
            val email = emailEditText.text.toString()

            if (name.isEmpty() || bio.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Sila isi semua ruang kosong", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Berjaya Kemaskini Profail", Toast.LENGTH_SHORT).show()
            }
        }

        // Set up click listener for the Halaman Utama button
        homeButton.setOnClickListener {
            // Navigate back to MainActivity
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()  // Close the current activity
        }

        // Set up click listener for the upload image button
        uploadImageButton.setOnClickListener {
            selectImage()
        }
    }

    // Function to handle image selection from gallery
    private fun selectImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        imagePickerLauncher.launch(intent)
    }

    // Activity result launcher to handle selected image
    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val selectedImageUri: Uri? = result.data?.data
            try {
                selectedImageUri?.let { uri ->
                    val bitmap = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                        val source = ImageDecoder.createSource(contentResolver, uri)
                        ImageDecoder.decodeBitmap(source)
                    } else {
                        MediaStore.Images.Media.getBitmap(contentResolver, uri)
                    }
                    profileImageView.setImageBitmap(bitmap)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "Gagal muat naik gambar", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
