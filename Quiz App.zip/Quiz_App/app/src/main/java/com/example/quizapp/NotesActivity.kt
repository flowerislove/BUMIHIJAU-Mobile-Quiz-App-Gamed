package com.example.quizapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class NotesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notesactivity)

        val buttonPemula: Button = findViewById(R.id.buttonPemula)
        val buttonSederhana: Button = findViewById(R.id.buttonSederhana)
        val buttonMaju: Button = findViewById(R.id.buttonMaju)

        buttonPemula.setOnClickListener {
            startActivity(Intent(this, NotesKSEasyActivity::class.java))
        }

        buttonSederhana.setOnClickListener {
            startActivity(Intent(this, NotesKSMediumActivity::class.java))
        }

        buttonMaju.setOnClickListener {
            startActivity(Intent(this, MajuActivity::class.java))
        }
    }
}
